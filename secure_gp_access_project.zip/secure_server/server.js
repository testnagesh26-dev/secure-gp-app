// server.js - simple activation server (demo)
const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const app = express();
app.use(bodyParser.json());

const activations = new Map();
const SERVER_SECRET = process.env.SERVER_SECRET || 'REPLACE_WITH_SECRET';

function hashCode(code){ return crypto.createHash('sha256').update(code).digest('hex'); }
function hmacDevice(deviceId){ return crypto.createHmac('sha256', SERVER_SECRET).update(deviceId).digest('hex'); }
function makeCode(){ return crypto.randomBytes(4).toString('hex').toUpperCase().slice(0,8); }

app.post('/admin/create', (req,res)=>{
  const code = makeCode();
  activations.set(hashCode(code), { codeHash: hashCode(code), used:false, expiresAt: Date.now()+30*24*3600*1000 });
  res.json({ code });
});

app.post('/request-code', (req,res)=>{ // mimic request -> email admin
  const { email, phone } = req.body;
  if(!email||!phone) return res.status(400).json({error:'missing'});
  const code = makeCode();
  activations.set(hashCode(code), { codeHash: hashCode(code), used:false, expiresAt: Date.now()+30*24*3600*1000, email, phone });
  console.log('[ADMIN-EMAIL] send code to admin:', code);
  res.json({ success:true });
});

app.post('/activate', (req,res)=>{
  const { code, email, phone, deviceId } = req.body;
  if(!code||!deviceId||!email||!phone) return res.status(400).json({error:'missing'});
  const ch = hashCode(code);
  const rec = activations.get(ch);
  if(!rec||rec.expiresAt < Date.now()) return res.status(400).json({error:'invalid_or_expired'});
  const deviceHash = hmacDevice(deviceId);
  if(!rec.used){ rec.used = true; rec.deviceHash = deviceHash; rec.token = crypto.randomBytes(16).toString('hex'); activations.set(ch,rec); return res.json({ success:true, token:rec.token, expiresAt:rec.expiresAt }); }
  if(rec.deviceHash === deviceHash) return res.json({ success:true, token:rec.token, expiresAt:rec.expiresAt });
  return res.status(403).json({ error:'code_already_used_by_other_device' });
});

app.listen(3000, ()=>console.log('server running on 3000'));