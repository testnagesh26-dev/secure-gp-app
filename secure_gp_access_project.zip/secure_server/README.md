Run: node server.js
