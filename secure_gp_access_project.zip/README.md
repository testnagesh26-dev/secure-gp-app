Secure GP Access - project. Use online builder to compile APK. Replace BASE_URL in code before building.
