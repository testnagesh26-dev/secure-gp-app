package com.securegpassist

import android.os.Bundle
import android.provider.Settings
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class ActivationActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_activate)
        val email = intent.getStringExtra("email") ?: ""
        val phone = intent.getStringExtra("phone") ?: ""
        val editCode = findViewById<EditText>(R.id.editCode)
        val btn = findViewById<Button>(R.id.btnActivate)
        btn.setOnClickListener {
            val code = editCode.text.toString().trim()
            if(code.isEmpty()){ Toast.makeText(this, "Enter code", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            // This placeholder does not call server; replace BASE_URL before building
            Toast.makeText(this, "Activation attempted (placeholder). Replace BASE_URL in code.", Toast.LENGTH_LONG).show()
        }
    }
}
