package com.securegpassist

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class RequestCodeActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_request_code)
        val editEmail = findViewById<EditText>(R.id.editEmail)
        val editPhone = findViewById<EditText>(R.id.editPhone)
        val btn = findViewById<Button>(R.id.btnRequest)
        btn.setOnClickListener {
            val email = editEmail.text.toString().trim()
            val phone = editPhone.text.toString().trim()
            if(email.isEmpty()||phone.isEmpty()){ Toast.makeText(this, "Enter email & phone", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            startActivity(Intent(this, ActivationActivity::class.java).apply { putExtra("email", email); putExtra("phone", phone) })
        }
    }
}
